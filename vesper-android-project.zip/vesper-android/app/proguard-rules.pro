## Rules for NewPipeExtractor (it runs Rhino, a JS engine, for signature deciphering)
-keep class org.mozilla.javascript.** { *; }
-keep class org.mozilla.classfile.ClassFileWriter
-dontwarn org.mozilla.javascript.tools.**
-dontwarn org.schabi.newpipe.**
