package com.vesper.app

import android.app.DownloadManager
import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Base64
import android.util.Log
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

/**
 * Native bridge exposed to the WebView as window.AndroidBridge.
 * Implements every method the Vesper HTML calls, so the page behaves exactly as
 * it does inside your existing native shell.
 */
class AndroidBridge(
    private val activity: AppCompatActivity,
    private val webView: WebView,
    private val scope: CoroutineScope
) {
    private var mediaPlayer: MediaPlayer? = null

    @JavascriptInterface
    fun isNativeAndroid(): Boolean = true

    @JavascriptInterface
    fun hapticTick(durationMs: Int) {
        try {
            val v = activity.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(durationMs.toLong(), VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION") v.vibrate(durationMs.toLong())
            }
        } catch (e: Throwable) { /* ignore */ }
    }

    @JavascriptInterface
    fun setKeepScreenOn(on: Boolean) {
        activity.runOnUiThread {
            try {
                if (on) activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            } catch (e: Throwable) { /* ignore */ }
        }
    }

    @JavascriptInterface fun pauseGyro() { /* no-op: no gyro stage in this build */ }
    @JavascriptInterface fun resumeGyro() { /* no-op */ }

    @JavascriptInterface
    fun isWifiConnected(): Boolean {
        return try {
            val cm = activity.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val net = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(net) ?: return false
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
        } catch (e: Throwable) { false }
    }

    @JavascriptInterface
    fun hideKeyboard() {
        activity.runOnUiThread {
            try {
                val imm = activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(webView.windowToken, 0)
            } catch (e: Throwable) { /* ignore */ }
        }
    }

    /** JioSaavn DES-ECB media URL decryption (key "38346591"), same as the JS fallback. */
    @JavascriptInterface
    fun decryptSaavnUrl(encBase64: String): String {
        return try {
            val key = SecretKeySpec("38346591".toByteArray(Charsets.UTF_8), "DES")
            val cipher = Cipher.getInstance("DES/ECB/PKCS5Padding")
            cipher.init(Cipher.DECRYPT_MODE, key)
            val dec = cipher.doFinal(Base64.decode(encBase64.trim(), Base64.DEFAULT))
            dec.toString(Charsets.UTF_8)
                .replace("http://", "https://")
                .replace("_96.mp4", "_320.mp4")
                .replace("_160.mp4", "_320.mp4")
        } catch (e: Throwable) { "" }
    }

    @JavascriptInterface
    fun playStream(url: String, title: String, artist: String, album: String, cover: String, duration: Int) {
        activity.runOnUiThread {
            try {
                mediaPlayer?.release()
                mediaPlayer = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    setDataSource(url)
                    setOnPreparedListener { it.start() }
                    prepareAsync()
                }
            } catch (e: Throwable) {
                Log.w("VesperBridge", "playStream failed", e)
            }
        }
    }

    @JavascriptInterface
    fun pauseStream() { activity.runOnUiThread { try { mediaPlayer?.pause() } catch (e: Throwable) {} } }

    @JavascriptInterface
    fun resumeStream() { activity.runOnUiThread { try { mediaPlayer?.start() } catch (e: Throwable) {} } }

    @JavascriptInterface
    fun seekTo(sec: Int) { activity.runOnUiThread { try { mediaPlayer?.seekTo(sec * 1000) } catch (e: Throwable) {} } }

    @JavascriptInterface
    fun setVolume(percent: Int) {
        activity.runOnUiThread {
            try {
                val f = percent.coerceIn(0, 100) / 100f
                mediaPlayer?.setVolume(f, f)
            } catch (e: Throwable) { /* ignore */ }
        }
    }

    @JavascriptInterface
    fun downloadTrack(url: String, title: String, artist: String, cover: String) {
        try {
            val dm = activity.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val safe = (title + " - " + artist).replace(Regex("[^\\w\\s-]"), "").trim()
            val req = DownloadManager.Request(Uri.parse(url))
                .setTitle(title)
                .setDescription(artist)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, "$safe.m4a")
            dm.enqueue(req)
        } catch (e: Throwable) {
            Log.w("VesperBridge", "download failed", e)
        }
    }

    // ---- Media session / DSP hooks the HTML calls; safe no-ops in this build ----
    @JavascriptInterface fun updatePlaybackMetadata(title: String, artist: String, album: String, isPlaying: Boolean, durMs: Long, posMs: Long, cover: String) {}
    @JavascriptInterface fun updateLiveLockscreenLyric(text: String) {}
    @JavascriptInterface fun extractColorsFromCover(url: String) {}
    @JavascriptInterface fun setEqualizerBand(band: Int, value: Int) {}
    @JavascriptInterface fun setBassBoost(value: Int) {}
    @JavascriptInterface fun setVocalSuppression(value: Int) {}

    @JavascriptInterface
    fun clearAppCacheAndMemory(): Long {
        var freed = 0L
        try {
            val cacheDir: File = activity.cacheDir
            freed = cacheDir.walkBottomUp().filter { it.isFile }.sumOf { it.length() }
            cacheDir.deleteRecursively()
        } catch (e: Throwable) { /* ignore */ }
        return freed / (1024 * 1024)
    }

    /**
     * THE AD-FREE RESOLVER. Called by the HTML as
     *   AndroidBridge.resolveYouTubeAudio(videoId, requestId)
     * and answers back via window.__vesperYT[requestId](directUrlOrEmptyString).
     */
    @JavascriptInterface
    fun resolveYouTubeAudio(videoId: String, requestId: String) {
        scope.launch(Dispatchers.IO) {
            val url = VesperYouTube.resolveAudioUrl(videoId)
            webView.post {
                val js = "window.__vesperYT && window.__vesperYT['$requestId'] && " +
                         "window.__vesperYT['$requestId'](${JSONObject.quote(url)})"
                webView.evaluateJavascript(js, null)
            }
        }
    }
}
