package com.vesper.app

import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.stream.StreamInfo
import java.util.Locale

/**
 * OkHttp-backed downloader required by NewPipeExtractor.
 */
class OkHttpDownloader(
    private val client: OkHttpClient = OkHttpClient()
) : Downloader() {

    override fun execute(request: Request): Response {
        val method = request.httpMethod()
        val url = request.url()
        val data = request.dataToSend()

        val builder = okhttp3.Request.Builder()
            .method(method, data?.toRequestBody())
            .url(url)

        request.headers().forEach { (name, value) -> builder.addHeader(name, value) }

        val response = client.newCall(builder.build()).execute()
        return Response(
            response.code,
            response.message,
            response.headers.toMultimap(),
            response.body?.string(),
            response.request.url.toString()
        )
    }
}

/**
 * On-device ad-free YouTube audio resolver (NewPipeExtractor).
 * Resolves the best audio-only stream URL from the DEVICE's own IP — full length,
 * full quality, correct song, and completely ad-free.
 */
object VesperYouTube {

    private const val TAG = "VesperYT"
    private val initLock = Any()

    @Volatile
    private var initialized = false

    fun ensureInit() {
        if (initialized) return
        synchronized(initLock) {
            if (initialized) return
            NewPipe.init(
                OkHttpDownloader(),
                Localization.fromLocale(Locale.US),
                ContentCountry("US")
            )
            initialized = true
        }
    }

    /** BLOCKING — call from a background thread. Returns "" on any failure. */
    fun resolveAudioUrl(videoId: String): String {
        ensureInit()
        return try {
            val watchUrl = "https://www.youtube.com/watch?v=$videoId"
            val info = StreamInfo.getInfo(ServiceList.YouTube, watchUrl)
            val best = info.audioStreams
                .filter { it.isUrl && !it.content.isNullOrEmpty() }
                .maxByOrNull { it.averageBitrate }
            best?.content ?: ""
        } catch (t: Throwable) {
            Log.w(TAG, "resolve failed for $videoId", t)
            ""
        }
    }
}
