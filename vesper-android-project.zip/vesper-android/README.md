# Vesper — Android project (WebView + native ad-free YouTube)

This is a complete, ready-to-build Android Studio project that wraps your
`vesper_v33.html` in a WebView and includes the **native ad-free YouTube
resolver** (NewPipeExtractor). Build it and you get an APK.

> If you already have your own Android project, you do NOT need this — just add
> `YouTubeNativeResolver.kt` to it and follow `VESPER_NATIVE_SETUP.md`.

## Build it

1. Install **Android Studio** (Hedgehog or newer) with the Android SDK.
2. `File → Open…` → select this `vesper-android` folder.
3. Let Gradle sync (first sync downloads Gradle + dependencies; needs internet).
   - If it complains the Gradle wrapper JAR is missing, run
     `gradle wrapper` once, or in Android Studio: *File → Sync Project with Gradle Files*.
4. `Build → Build Bundle(s) / APK(s) → Build APK(s)`.
5. The APK lands at `app/build/outputs/apk/debug/app-debug.apk`.
   Copy it to your phone and install (enable "Install unknown apps").

Command line alternative:
```
./gradlew assembleDebug      # or: gradle assembleDebug
```

## What's inside

| File | Purpose |
|------|---------|
| `app/src/main/assets/vesper_v33.html` | your app UI (the build `native6` file) |
| `MainActivity.kt` | hosts the WebView, loads the HTML, registers the bridge |
| `AndroidBridge.kt` | every `window.AndroidBridge.*` method the HTML calls |
| `YouTubeNativeResolver.kt` | NewPipeExtractor — the ad-free audio resolver |

## How the ad-free path works

```
vesper_v33.html  ──AndroidBridge.resolveYouTubeAudio(id, reqId)──►  AndroidBridge.kt
                                                                        │
                                                            VesperYouTube.resolveAudioUrl(id)
                                                                        │  (NewPipeExtractor)
                                                                        ▼
                                        direct googlevideo audio URL ──► window.__vesperYT[reqId](url)
                                                                        │
                                                                        ▼
                                                     played by the WebView / native MediaPlayer
```

The stream is fetched from the phone's own IP, so it is full-length,
full-quality, the correct song, and has **no ad breaks at all**.

## Notes / caveats

- **Requires a rebuild** — the HTML alone can't do this; the APK must be rebuilt.
- **minSdk 24**; core-library desugaring is already enabled for NewPipeExtractor.
- **Keep NewPipeExtractor fresh** — YouTube changes break extractors periodically.
  Bump the version in `app/build.gradle` when playback starts failing.
  Watch https://github.com/TeamNewPipe/NewPipeExtractor/releases
- **No launcher icon** is included (uses the system default) to keep the project
  free of binary assets — add your own in `res/mipmap-*` if you want.
- **Signing**: this builds a *debug* APK, fine for personal use. For a release
  APK, add your keystore in Android Studio (`Build → Generate Signed Bundle/APK`).
- Extracting YouTube streams is against YouTube's ToS — same trade-off every
  ad-free client makes. Personal use.
